# Sahro MMORPG - React & Tailwind Project

Ushbu arxiv Sahro MMORPG o'yinining tartibli, modullarga bo'lingan va to'g'rilangan versiyasini o'z ichiga oladi.

## Ishga tushirish uchun qadamlar:
1. Node.js o'rnatilgan bo'lishi kerak.
2. Terminalda loyiha papkasiga kiring:
   ```bash
   cd sahro_mmorpg
   ```
3. Kutubxonalarni o'rnating:
   ```bash
   npm install
   ```
4. Loyihani ishga tushiring:
   ```bash
   npm run dev
   ```
