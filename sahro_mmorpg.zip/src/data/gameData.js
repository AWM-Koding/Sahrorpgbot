export const Uv = [
  {id:"Qishloq", name:"Qishloq", emoji:"🏠", lvl:"1", color:"#22c55e", desc:"Xavfsiz hudud", monsters:"Hech kim yo'q"},
  {id:"Ormon", name:"O'rmon", emoji:"🌲", lvl:"1-5", color:"#16a34a", desc:"Boshlang'ich yovlar", monsters:"Hasharotlar"},
  {id:"Gor", name:"G'or", emoji:"🕳️", lvl:"5-15", color:"#78716c", desc:"Qorong'u g'orlar", monsters:"Sudraluvchilar"},
  {id:"Chol", name:"Sahro", emoji:"🏜️", lvl:"15-25", color:"#d4a574", desc:"Cheksiz qum", monsters:"Yirtqichlar - SAHRO", special:true}
];

export const De = [
  {id:"w1", name:"Yog'och Qilich", type:"weapon", rarity:"common", atk:8, value:100, icon:"🗡️"},
  {id:"w2", name:"Temir Qilich", type:"weapon", rarity:"uncommon", atk:18, value:500, icon:"⚔️"}
];

export const uu = [
  {id:"a1", name:"Mato Ko'ylak", type:"armor", rarity:"common", def:5, value:80, icon:"👕"},
  {id:"a2", name:"Charm Zirh", type:"armor", rarity:"uncommon", def:12, value:400, icon:"🦺"}
];

export const Ov = {
  Hasharotlar: {range:[1,50], icon:"🐛", color:"#22c55e"},
  Sudraluvchilar: {range:[51,100], icon:"🐍", color:"#a3a3a3"}
};

export const jn = [
  {id:1, name:"Yovvoyi Qurt 1", hp:50, maxHp:50, atk:10, def:5, gold:20, xp:15, category:"Hasharotlar", loc:"Ormon", icon:"🐛"}
];

export const Qv = [];
export const iu = [{x:20, y:20, name:"Yashil Voha"}];
export const If = [{name:"1000 tanga", gold:1000, icon:"💰"}];
