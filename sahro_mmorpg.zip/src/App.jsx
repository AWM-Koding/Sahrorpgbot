import React, { useState, useEffect, useRef } from 'react';
import { Uv, De, uu, Ov, jn, Qv, iu, If } from './data/gameData';

export default function App() {
  const [tab, setTab] = useState("Qahramon");
  const [toast, setToast] = useState(null);
  
  const showToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2000);
  };

  return (
    <div className="min-h-screen bg-[#070a14] text-white p-4">
      <h1 className="text-2xl font-bold text-center text-yellow-400 mb-4">Sahro MMORPG - Boshqaruv Paneli</h1>
      <div className="flex justify-center gap-2 flex-wrap mb-6">
        {["Qahramon", "Dunyo", "Sumka", "Do'kon"].map((t) => (
          <button 
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition ${tab === t ? 'bg-yellow-500 text-black' : 'bg-white/10 hover:bg-white/20'}`}
          >
            {t}
          </button>
        ))}
      </div>
      <div className="max-w-4xl mx-auto glass rounded-2xl p-6 text-center">
        {tab === "Qahramon" && <div>Qahramon bo'limi (Modulli versiya muvaffaqiyatli ishga tushdi!)</div>}
        {tab === "Dunyo" && <div>Dunyo xaritasi va hududlar</div>}
        {tab === "Sumka" && <div>Inventar va buyumlar</div>}
        {tab === "Do'kon" && <div>Do'kon va qurollar</div>}
      </div>
      {toast && <div className="fixed bottom-10 left-1/2 -translate-x-1/2 bg-yellow-500 text-black px-4 py-2 rounded-full font-bold shadow-lg">{toast}</div>}
    </div>
  );
}
